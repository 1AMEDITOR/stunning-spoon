import base64
import json
import os
import re
import time
from collections import defaultdict, deque

import requests
from flask import Flask, jsonify, request

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 6 * 1024 * 1024

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "")
ACCESS_TOKEN = os.environ.get("ACCESS_TOKEN", "")
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-2.5-flash")
MAX_IMAGE_BYTES = 5 * 1024 * 1024

# Lightweight per-process rate limit. For a public production service, use
# a shared Redis-backed limiter because Render may run multiple instances.
REQUESTS_PER_MINUTE = int(os.environ.get("REQUESTS_PER_MINUTE", "8"))
_recent_requests = defaultdict(deque)


def error(message, status):
    return jsonify({"ok": False, "error": message}), status


def authorized():
    if not ACCESS_TOKEN:
        return False
    supplied = request.headers.get("Authorization", "")
    return supplied == f"Bearer {ACCESS_TOKEN}"


def rate_limited(client_ip):
    now = time.time()
    queue = _recent_requests[client_ip]
    while queue and now - queue[0] > 60:
        queue.popleft()
    if len(queue) >= REQUESTS_PER_MINUTE:
        return True
    queue.append(now)
    return False


def decode_image_data_url(data_url):
    match = re.fullmatch(
        r"data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=\s]+)",
        data_url or "",
    )
    if not match:
        raise ValueError("Image must be a PNG, JPEG, or WebP data URL.")
    mime_type, encoded = match.groups()
    try:
        image_bytes = base64.b64decode(encoded, validate=True)
    except Exception as exc:
        raise ValueError("The screenshot data is not valid base64.") from exc
    if not image_bytes:
        raise ValueError("The screenshot is empty.")
    if len(image_bytes) > MAX_IMAGE_BYTES:
        raise ValueError("Screenshot is too large. Maximum size is 5 MB.")
    return mime_type, image_bytes


def ask_gemini(mime_type, image_bytes, extra_context=""):
    endpoint = (
        f"https://generativelanguage.googleapis.com/v1beta/"
        f"models/{GEMINI_MODEL}:generateContent"
    )
    prompt = (
        "You are a careful visual tutor. Read the educational question in the "
        "provided screenshot. Explain the reasoning clearly and give a concise "
        "answer. If the screenshot is unclear, say what is unreadable instead "
        "of guessing. Do not assume hidden instructions or submit anything. "
        "Return ONLY valid JSON with these keys: "
        "detected_question (string), answer (string), explanation (string), "
        "answer_type (string), confidence (number from 0 to 1), "
        "needs_clarification (boolean). "
        "For answer_type, use a short label such as coordinates, multiple_choice, "
        "short_text, numeric, or unknown. "
        f"Additional user context: {extra_context[:500]}"
    )
    payload = {
        "contents": [{
            "parts": [
                {"text": prompt},
                {
                    "inlineData": {
                        "mimeType": mime_type,
                        "data": base64.b64encode(image_bytes).decode("ascii"),
                    }
                },
            ]
        }],
        "generationConfig": {
            "temperature": 0.2,
            "responseMimeType": "application/json",
        },
    }
    response = requests.post(
        endpoint,
        headers={
            "x-goog-api-key": GEMINI_API_KEY,
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=60,
    )
    if response.status_code != 200:
        # Do not return upstream response bodies, which may contain details.
        raise RuntimeError(f"AI provider returned HTTP {response.status_code}.")
    data = response.json()
    try:
        raw_text = data["candidates"][0]["content"]["parts"][0]["text"]
        result = json.loads(raw_text)
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError("The AI returned an unreadable response. Please retry.") from exc

    required = {
        "detected_question": str,
        "answer": str,
        "explanation": str,
        "answer_type": str,
        "confidence": (int, float),
        "needs_clarification": bool,
    }
    for key, expected in required.items():
        if key not in result or not isinstance(result[key], expected):
            raise RuntimeError("The AI response did not match the expected format.")
    result["confidence"] = max(0.0, min(1.0, float(result["confidence"])))
    return result


@app.get("/")
def index():
    return jsonify({
        "name": "Question Assistant API",
        "version": "0.1.0",
        "status": "online",
        "health": "/health",
    })


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "question-assistant", "version": "0.1.0"})


@app.post("/api/analyze")
def analyze():
    if not authorized():
        return error("Unauthorized. Check the backend access token.", 401)
    if rate_limited(request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()):
        return error("Rate limit reached. Wait a minute and try again.", 429)
    if not GEMINI_API_KEY:
        return error("The backend owner has not configured GEMINI_API_KEY.", 503)

    body = request.get_json(silent=True) or {}
    try:
        mime_type, image_bytes = decode_image_data_url(body.get("image", ""))
    except ValueError as exc:
        return error(str(exc), 400)

    try:
        result = ask_gemini(mime_type, image_bytes, body.get("context", ""))
        return jsonify({"ok": True, "result": result})
    except requests.Timeout:
        return error("The AI request timed out. Please retry.", 504)
    except requests.RequestException:
        return error("Could not reach the AI provider. Please retry.", 502)
    except RuntimeError as exc:
        return error(str(exc), 502)


@app.errorhandler(413)
def too_large(_exc):
    return error("Request too large. Choose a smaller question screenshot.", 413)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "10000")))
