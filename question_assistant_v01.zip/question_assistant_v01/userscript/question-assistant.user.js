// ==UserScript==
// @name         Question Assistant (v0.1)
// @namespace    local.question-assistant
// @version      0.1.0
// @description  Select a question on a page, send its screenshot to your hosted AI tutor, and review the explanation.
// @match        *://*/*
// @grant        GM_xmlhttpRequest
// @connect      *
// @require      https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js
// @run-at       document-idle
// ==/UserScript==

(() => {
  "use strict";

  // CHANGE THESE TWO VALUES after deploying the backend.
  const API_URL = "https://YOUR-RENDER-SERVICE.onrender.com";
  const ACCESS_TOKEN = "PASTE_YOUR_BACKEND_ACCESS_TOKEN_HERE";

  const STYLE_ID = "qa-assistant-styles";
  const PANEL_ID = "qa-assistant-panel";
  if (document.getElementById(PANEL_ID)) return;

  const style = document.createElement("style");
  style.id = STYLE_ID;
  style.textContent = `
    #${PANEL_ID}{position:fixed;right:20px;bottom:20px;width:330px;max-height:75vh;
      z-index:2147483647;background:#171923;color:#f7f7fb;border:1px solid #45495b;
      border-radius:14px;box-shadow:0 12px 40px #0007;font:14px/1.45 system-ui,sans-serif;
      overflow:hidden}
    #${PANEL_ID} *{box-sizing:border-box}
    #${PANEL_ID} .qa-head{display:flex;align-items:center;justify-content:space-between;
      padding:11px 13px;background:#242838;cursor:move;font-weight:700}
    #${PANEL_ID} .qa-body{padding:12px;overflow:auto;max-height:calc(75vh - 44px)}
    #${PANEL_ID} button{border:0;border-radius:8px;padding:9px 11px;background:#6875f5;
      color:white;font-weight:650;cursor:pointer;margin:3px 3px 3px 0}
    #${PANEL_ID} button.secondary{background:#34394b}
    #${PANEL_ID} button:disabled{opacity:.55;cursor:wait}
    #${PANEL_ID} .qa-muted{color:#b8bdd0;font-size:12px}
    #${PANEL_ID} .qa-card{background:#222738;border-radius:9px;padding:10px;margin-top:9px;
      white-space:pre-wrap;overflow-wrap:anywhere}
    #${PANEL_ID} .qa-answer{font-size:15px;font-weight:700}
    #${PANEL_ID} .qa-status{margin:8px 0;color:#cbd0e2}
    #${PANEL_ID} textarea{width:100%;min-height:54px;resize:vertical;background:#10131d;
      color:#fff;border:1px solid #4b5268;border-radius:8px;padding:8px}
    #qa-picker-shade{position:fixed;inset:0;z-index:2147483646;pointer-events:none;
      background:#6479ff18;outline:3px dashed #6577ff;outline-offset:-5px}
    .qa-hover-outline{outline:3px solid #6577ff!important;outline-offset:2px!important}
  `;
  document.documentElement.appendChild(style);

  const panel = document.createElement("section");
  panel.id = PANEL_ID;
  panel.innerHTML = `
    <div class="qa-head"><span>✦ Question Assistant</span>
      <button class="secondary" id="qa-min" title="Minimize">−</button></div>
    <div class="qa-body" id="qa-body">
      <div class="qa-muted">Select the question area on this page. The screenshot is sent to your configured AI backend.</div>
      <textarea id="qa-context" placeholder="Optional context (e.g. 'show the coordinates only')"></textarea>
      <div>
        <button id="qa-select">Select question</button>
        <button id="qa-analyze" class="secondary" disabled>Analyze screenshot</button>
      </div>
      <div class="qa-status" id="qa-status">Backend not checked yet.</div>
      <div id="qa-result"></div>
    </div>`;
  document.body.appendChild(panel);

  const $ = (id) => panel.querySelector("#" + id);
  let selectedElement = null;
  let screenshotData = null;
  let pickerActive = false;
  let minimized = false;

  function status(message) { $("qa-status").textContent = message; }

  $("qa-min").addEventListener("click", () => {
    minimized = !minimized;
    $("qa-body").style.display = minimized ? "none" : "block";
    $("qa-min").textContent = minimized ? "+" : "−";
  });

  // Make the floating panel draggable using its header.
  const header = panel.querySelector(".qa-head");
  let drag = null;
  header.addEventListener("pointerdown", (event) => {
    if (event.target.closest("button")) return;
    const rect = panel.getBoundingClientRect();
    drag = {x: event.clientX, y: event.clientY, left: rect.left, top: rect.top};
    header.setPointerCapture(event.pointerId);
  });
  header.addEventListener("pointermove", (event) => {
    if (!drag) return;
    panel.style.left = Math.max(0, drag.left + event.clientX - drag.x) + "px";
    panel.style.top = Math.max(0, drag.top + event.clientY - drag.y) + "px";
    panel.style.right = "auto";
    panel.style.bottom = "auto";
  });
  header.addEventListener("pointerup", () => { drag = null; });

  function stopPicker() {
    pickerActive = false;
    document.removeEventListener("mouseover", onHover, true);
    document.removeEventListener("click", onPick, true);
    document.removeEventListener("keydown", onPickerKey, true);
    document.getElementById("qa-picker-shade")?.remove();
    document.querySelectorAll(".qa-hover-outline").forEach(el => el.classList.remove("qa-hover-outline"));
  }
  function onHover(event) {
    if (!pickerActive || panel.contains(event.target)) return;
    document.querySelectorAll(".qa-hover-outline").forEach(el => el.classList.remove("qa-hover-outline"));
    event.target.classList.add("qa-hover-outline");
  }
  function onPick(event) {
    if (!pickerActive || panel.contains(event.target)) return;
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    selectedElement = event.target;
    screenshotData = null;
    $("qa-analyze").disabled = true;
    stopPicker();
    status("Selected: " + selectedElement.tagName.toLowerCase() + ". Preparing screenshot…");
    captureSelected();
  }
  function onPickerKey(event) {
    if (event.key === "Escape") {
      stopPicker();
      status("Selection cancelled.");
    }
  }

  $("qa-select").addEventListener("click", () => {
    if (!window.html2canvas) {
      status("Screenshot library did not load. Refresh the page and try again.");
      return;
    }
    pickerActive = true;
    const shade = document.createElement("div");
    shade.id = "qa-picker-shade";
    document.body.appendChild(shade);
    status("Click the question itself. Press Escape to cancel.");
    document.addEventListener("mouseover", onHover, true);
    document.addEventListener("click", onPick, true);
    document.addEventListener("keydown", onPickerKey, true);
  });

  async function captureSelected() {
    try {
      const canvas = await window.html2canvas(selectedElement, {
        backgroundColor: "#ffffff",
        scale: Math.min(2, window.devicePixelRatio || 1),
        useCORS: true,
        logging: false,
        ignoreElements: el => el.id === PANEL_ID || el.id === "qa-picker-shade"
      });
      screenshotData = canvas.toDataURL("image/png");
      $("qa-analyze").disabled = false;
      status("Screenshot ready. Review it on the page, then choose Analyze.");
    } catch (err) {
      status("Could not capture that element. Try selecting a simpler question container. " + err.message);
    }
  }

  function requestBackend(payload) {
    return new Promise((resolve, reject) => {
      GM_xmlhttpRequest({
        method: "POST",
        url: API_URL.replace(/\/$/, "") + "/api/analyze",
        headers: {
          "Content-Type": "application/json",
          "Authorization": "Bearer " + ACCESS_TOKEN
        },
        data: JSON.stringify(payload),
        timeout: 70000,
        onload: response => {
          let data;
          try { data = JSON.parse(response.responseText); }
          catch (_) { reject(new Error("Backend returned an invalid response.")); return; }
          if (response.status >= 200 && response.status < 300 && data.ok) resolve(data.result);
          else reject(new Error(data.error || ("Backend error " + response.status)));
        },
        onerror: () => reject(new Error("Could not connect to the backend.")),
        ontimeout: () => reject(new Error("The request timed out."))
      });
    });
  }

  $("qa-analyze").addEventListener("click", async () => {
    if (!screenshotData) return;
    $("qa-analyze").disabled = true;
    $("qa-result").textContent = "";
    status("Sending screenshot to the AI…");
    try {
      const result = await requestBackend({
        image: screenshotData,
        context: $("qa-context").value || ""
      });
      const card = document.createElement("div");
      card.className = "qa-card";
      const question = document.createElement("div");
      question.innerHTML = "<strong>Detected question</strong>";
      const questionText = document.createElement("div");
      questionText.textContent = result.detected_question;
      const answerTitle = document.createElement("div");
      answerTitle.innerHTML = "<strong>Suggested answer</strong>";
      const answerText = document.createElement("div");
      answerText.className = "qa-answer";
      answerText.textContent = result.answer;
      const explanationTitle = document.createElement("div");
      explanationTitle.innerHTML = "<strong>Explanation</strong>";
      const explanationText = document.createElement("div");
      explanationText.textContent = result.explanation;
      const meta = document.createElement("div");
      meta.className = "qa-muted";
      meta.textContent = "Type: " + result.answer_type +
        " · AI confidence estimate: " + Math.round(result.confidence * 100) + "%" +
        (result.needs_clarification ? " · Needs clarification" : "");
      const copy = document.createElement("button");
      copy.className = "secondary";
      copy.textContent = "Copy suggested answer";
      copy.addEventListener("click", async () => {
        await navigator.clipboard.writeText(result.answer);
        copy.textContent = "Copied";
      });
      card.append(question, questionText, answerTitle, answerText,
        explanationTitle, explanationText, meta, copy);
      $("qa-result").appendChild(card);
      status("Analysis complete. Check the answer before using it.");
    } catch (err) {
      status("Error: " + err.message);
    } finally {
      $("qa-analyze").disabled = !screenshotData;
    }
  });

  if (API_URL.includes("YOUR-RENDER-SERVICE") || ACCESS_TOKEN.includes("PASTE_YOUR")) {
    status("Setup needed: edit API_URL and ACCESS_TOKEN in the userscript.");
  } else {
    status("Ready. Select a question to begin.");
  }
})();
