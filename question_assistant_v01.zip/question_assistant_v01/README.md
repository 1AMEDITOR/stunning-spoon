# Question Assistant v0.1

A small floating Tampermonkey assistant that captures a selected question element,
sends the screenshot to a Python backend, and asks Gemini to explain it.

This first version is deliberately **review-first**: it does not fill in forms,
click answer choices, submit work, or press Enter.

## Project layout

```text
question_assistant_v01/
├── backend/
│   ├── app.py
│   └── requirements.txt
├── render.yaml
├── userscript/
│   └── question-assistant.user.js
└── README.md
```

## 1. Get a Gemini API key

Create an API key in Google AI Studio:
https://aistudio.google.com/app/apikey

Check the current Gemini API pricing and free-tier availability before use:
https://ai.google.dev/gemini-api/docs/pricing

Do not put this key in the userscript or share it with anyone.

## 2. Deploy the backend to Render

1. Put this project in a Git repository.
2. In Render, choose **New → Blueprint** and connect the repository. The root-level
   `render.yaml` configures the service to use the `backend` folder. Alternatively,
   create a Python Web Service using `backend` as its root directory.
3. For a manually created Web Service, use:
   - Build command: `pip install -r requirements.txt`
   - Start command: `gunicorn app:app`
4. Add environment variables:
   - `GEMINI_API_KEY`: your Google AI Studio key
   - `ACCESS_TOKEN`: a long random secret (at least 32 random characters)
   - `GEMINI_MODEL`: `gemini-2.5-flash`
   - `REQUESTS_PER_MINUTE`: `8`
5. If deploying the Blueprint, Render will prompt for both secret values. Set
   `GEMINI_API_KEY` and `ACCESS_TOKEN`; keep both private.
6. After deployment, visit `https://YOUR-SERVICE.onrender.com/health`.
   You should see `{"ok":true,...}`.

Render's free web services may sleep after inactivity, so the first request after
a quiet period can take longer.

## 3. Install the userscript

1. Install Tampermonkey in your browser.
2. Open the Tampermonkey dashboard and create a new script.
3. Replace its contents with `userscript/question-assistant.user.js`.
4. Edit these two constants near the top:
   - `API_URL`: your Render service URL, without a trailing slash.
   - `ACCESS_TOKEN`: the same secret configured on Render.
5. Save and refresh an educational webpage.

## 4. Use it

1. Open the floating **Question Assistant** panel.
2. Click **Select question**.
3. Click the question area on the page. Press Escape to cancel selection.
4. Wait for the screenshot to be prepared.
5. Optionally add context, then click **Analyze screenshot**.
6. Review the suggested answer and explanation.

## Important limitations

- This uses `html2canvas` to reconstruct a screenshot from webpage elements. It is
  not a true operating-system/browser screenshot. Some canvas content, cross-origin
  images, embedded documents, protected pages, and complex sites may not capture
  correctly.
- Selecting a container that includes the question, diagram, and answer choices
  generally works better than selecting one tiny text element.
- Some sites prohibit automated access or have rules about AI assistance. Follow
  the site's rules and use this as a learning aid.
- The AI can make mistakes. Check calculations, diagrams, and answers yourself.
- The in-memory rate limit is a basic safeguard, not a production-grade abuse
  prevention system. For a public deployment, add a shared rate limiter, stronger
  account-level authentication, monitoring, and request quotas.
- Never expose `GEMINI_API_KEY` in the userscript, browser storage, or public repo.
- The userscript's access token is visible to the person using that browser profile.
  Do not distribute a shared public token. A multi-user version should add user
  accounts and per-user authentication.
- Screenshots are sent to the backend and then to Google's Gemini API. Avoid
  including names, account details, grades, or other private information.

## Local backend test (optional)

```bash
cd backend
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
# Set GEMINI_API_KEY and ACCESS_TOKEN in your environment, then:
python app.py
```

Health check: `http://127.0.0.1:10000/health`
